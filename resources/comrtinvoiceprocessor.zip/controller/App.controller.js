sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.rt.invoiceprocessor.controller.process_invoice",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map